# Rozwiązania zadań lab 5

## zadanie 1

```python
Person.objects.all()
```

## zadanie 2