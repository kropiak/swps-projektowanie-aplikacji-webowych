# Rozwiązania zadań lab 5

## zadanie 1

```console
# uruchamian Django shell
python manage.py shell
```

```python
# przykład (skopiowane z terminala)
>>> p1 = Person() 
>>> p1.firstname = 'Mariusz'
>>> p1.lastname = 'Zdanowicz'
>>> p1.shirt_size = 'M'
>>> p1.month_added = 8
>>> p1.save()
```

## zadanie 2
...